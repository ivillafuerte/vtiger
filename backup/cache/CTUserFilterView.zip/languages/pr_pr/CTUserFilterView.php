<?php
/*+*******************************************************************************
 * The content of this file is subject to the CRMTiger Pro license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is vTiger
 * The Modified Code of the Original Code owned by https://crmtiger.com/
 * Portions created by CRMTiger.com are Copyright(C) CRMTiger.com
 * All Rights Reserved.
  ***************************************************************************** */

$languageStrings = Array(
	'CTUserFilterView' => 'فیلتر کاربر CTMobile',
	'SINGLE_CTUserFilterView' => 'فیلتر کاربر CTMobile',
	'CTUserFilterView ID' => 'شناسه فیلتر کاربر CTMobile',
	
	'User Filter View No' => 'کاربر فیلتر مشاهده ندارد',
	'Module Name' => 'نام ماژول',
	'Filter' => 'فیلتر کردن',
	'Filter Name' => 'نام فیلتر',
	'CTMobile User Filter View Information' => 'اطلاعات کاربر فیلتر مشاهده',
	

	'LBL_CUSTOM_INFORMATION' => 'Custom Information',
	'LBL_MODULEBLOCK_INFORMATION' => 'ModuleBlock Information',

	'ModuleFieldLabel' => 'ModuleFieldLabel Text',
);

?>
